frukter= ["Epple", "banan", "kiwi", "mango", "jordbaer"]
nyListeMedFrukt =[x for x in frukter if "a" in x]
print (nyListeMedFrukt)
