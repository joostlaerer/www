frukter= ["Epple", "banan", "kiwi", "mango", "jordbaer"]
nyListeMedFrukt =[]

""" plukk ut alle med bokstav a """
for x in frukter:
    if "a" in x:
        nyListeMedFrukt.append(x)
print(nyListeMedFrukt)
    

