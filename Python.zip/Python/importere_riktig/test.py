import inputs

""" Program som spytter ut en string """
def main():
    inputs.skrivInnInfo()
    
if __name__ == "__main__":
  main()
    

