def aapneOgLukkeFil(filename):
    f = open(filename,"w")
    f.write("hello!\n")
    f.close()

aapneOgLukkeFil("test.txt")
