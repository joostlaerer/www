""" Program som spytter ut en string """
def skrivInnInfo():
    fnavn=input ("Skriv inn fornavnet navnet ditt: ")
    enavn=input ("Skriv inn etternavnet ditt: ")
    bursdag= input ("Skriv inn når du har bursdag: ")
