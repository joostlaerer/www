import inputs

""" Program som spytter ut en string """
def main():
  herSkalDetStoppe= input("hubba bubba")
  inputs.skrivInnInfo()





    

